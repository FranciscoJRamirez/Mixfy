<?php 

include 'connection.php';

$cat=$_GET['cat'];
$query= "SELECT restaurantes.nombre as restaurante, platillos.nombre, 
platillos.precio, platillos.imagen 
FROM platillos 
join restaurantes 
on platillos.id_res=restaurantes.id_res
WHERE platillos.id_cat=$cat";
$datos = Array();
$rasul = mysqli_query($connection, $query);
while($row = mysqli_fetch_object($rasul)){
    $datos[] = $row;
}
echo json_encode($datos);

?>