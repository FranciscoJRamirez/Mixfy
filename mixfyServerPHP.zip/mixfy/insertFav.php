<?php 

include 'connection.php';

$user=$_GET['id_u'];
$rec = $_GET['id_r'];
$query= $connection->prepare("INSERT INTO favoritorec (id_rec, id_usuario) VALUES ($rec, $user)");

if($query->execute()){
    echo "Registro del usuario existoso";
}
else {
    echo 'Error al intentar registrar al usuario';
}
$query->close();

?>