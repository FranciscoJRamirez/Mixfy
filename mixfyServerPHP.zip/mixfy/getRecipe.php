<?php 

include 'connection.php';

$query= "SELECT * FROM recetas";
$datos = Array();
$rasul = mysqli_query($connection, $query);
while($row = mysqli_fetch_object($rasul)){
    $datos[] = $row;
}
echo json_encode($datos);

?>