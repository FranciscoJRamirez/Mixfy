<?php 

include 'connection.php';

$id=$_GET['id'];
$query= "select recetas.nombrerec from recetas join favoritorec on recetas.id_rec=favoritorec.id_rec 
join usuarios on usuarios.id_usuarios=favoritorec.id_usuario where usuarios.id_usuarios = $id";
$datos = Array();
$rasul = mysqli_query($connection, $query);
while($row = mysqli_fetch_object($rasul)){
    $datos[] = $row;
}
echo json_encode($datos);

?>