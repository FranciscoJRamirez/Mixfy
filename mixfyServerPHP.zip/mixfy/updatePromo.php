<?php
include 'connection.php';
$id = $_GET["id"];
$query= ("UPDATE cupones SET disponible=false WHERE id_cupon = $id");
//$query->bind_param('s', $id);
if (mysqli_query($connection, $query)) {
    echo "Record updated successfully";
  } else {
    echo "Error updating record: " . mysqli_error($connection);
  }

?>