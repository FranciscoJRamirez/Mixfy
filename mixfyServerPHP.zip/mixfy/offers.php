<?php
include 'connection.php';

$query= "SELECT serial FROM cupones";

$result = $connection -> query($query);

while ($file=$result->fetch_array()){
    echo $json= json_encode($file, JSON_UNESCAPED_UNICODE);
    //echo $img = $file['imagen'];
    //echo '<img src="data:image/jpeg;base64,'.base64_encode(($img)) .' "/>';
    //$obj = json_decode($json);
    //echo $obj->{'serial'};
    
}
$result->close();
?>