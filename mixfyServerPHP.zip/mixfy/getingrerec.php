<?php 

include 'connection.php';

$cat=$_GET['cat'];
$query= "select ingredientes.nombreing 
from ingredientes join ingre_recetas on ingredientes.id_ingrediente = 
ingre_recetas.id_ingrediente join recetas on recetas.id_rec=ingre_recetas.id_rec where recetas.id_rec=$cat";
$datos = Array();
$rasul = mysqli_query($connection, $query);
while($row = mysqli_fetch_object($rasul)){
    $datos[] = $row;
}
echo json_encode($datos);

?>