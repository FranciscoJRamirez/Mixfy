<?php 

include 'connection.php';

$id = $_GET["id"];

$query= "SELECT promos, realizadas, visitados FROM usuarios WHERE id_usuarios=$id";
$datos = Array();
$rasul = mysqli_query($connection, $query);
while($row = mysqli_fetch_object($rasul)){
    $datos[] = $row;
}
echo json_encode($datos);

?>