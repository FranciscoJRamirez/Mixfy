<?php 

include 'connection.php';

$query= "SELECT restaurantes.nombre as restaurante, platillos.nombre, 
platillos.precio, platillos.imagen 
FROM platillos 
join restaurantes 
on platillos.id_res=restaurantes.id_res";
$datos = Array();
$rasul = mysqli_query($connection, $query);
while($row = mysqli_fetch_object($rasul)){
    $datos[] = $row;
}
echo json_encode($datos);

?>